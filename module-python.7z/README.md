<p align="center"><a href="https://bearsampp.com/contribute" target="_blank"><img width="250" src="img/Bearsampp-logo.svg"></a></p>

[![GitHub release](https://img.shields.io/github/release/bearsampp/module-python.svg?style=flat-square)](https://github.com/bearsampp/module-python/releases/latest)
![Total downloads](https://img.shields.io/github/downloads/bearsampp/module-python/total.svg?style=flat-square)

This is a module of [Bearsampp project](https://github.com/bearsampp/bearsampp) involving Python.

## Documentation and downloads

https://bearsampp.com/module/python

## Issues

Issues must be reported on [Bearsampp repository](https://github.com/bearsampp/bearsampp/issues).
